<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Requirements</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <div id="layoutAuthentication">
                <div id="layoutAuthentication_content">
                    <main>
                    <?php
                        
                        if (isset($_SESSION['successmessage'])) {
                        ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Successful</strong> 
                                <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php

                            unset($_SESSION['successmessage']);
                        }
                        ?>
                        <?php
                        
                        if (isset($_SESSION['errormessage'])) {
                        ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Error:</strong> <?php echo $_SESSION['errormessage']; ?>
                                <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php

                            unset($_SESSION['errormessage']);
                        }
                        ?>
                        <div class="d-flex justify-content-center container-fluid">
                            <div class="col-lg-8">
                                <div class="card border border-dark mb-4">
                                    <div class="d-flex justify-content-center card-header bg-warning text-dark">
                                        <h2 class="card-title text-center"><b>Requirements</b></h2>
                                    </div>
                                    <div class="card-body px-5 pt-4">
                                        <div class="row">
                                            <div class="col-sm-8">
                                                <p class="blockquote mb-0">Personal Data Sheet</p>
                                            </div>
                                            <div class="col-sm-4 d-flex justify-content-end">
                                                <?php
                                                include 'db_connect.php';
                                                if ($mysqli->connect_errno) {
                                                    die("Connection error: " . $mysqli->connect_error);
                                                }
                                                $user = $_SESSION["user"];
                                                $sql = "SELECT * from student_infomation where id=$user";
                                                $result = $mysqli->query($sql);
                                                $row = $result->fetch_assoc();
                                                if (empty($row)) {

                                                ?>

                                                    <button type='button' class='btn btn-primary btn-sm' data-toggle="modal" data-target="#myModal"><i class='bi bi-cloud-download-fill mx-2'></i>Send</button>
                                                <?php
                                                } else
                                                    echo "<div><i class='bi bi-check-circle text-success'> Done</i></div>";
                                                ?>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-8">
                                                <p class="blockquote mb-0">Parent Consent</p>
                                            </div>
                                            <div class="col-sm-4 d-flex justify-content-end">
                                                <?php
                                                include 'db_connect.php';
                                                if ($mysqli->connect_errno) {
                                                    die("Connection error: " . $mysqli->connect_error);
                                                }
                                                $user = $_SESSION["user"];
                                                $sql = "SELECT * from parent_con_db where std_id=$user";
                                                $result = $mysqli->query($sql);
                                                $row = $result->fetch_assoc();
                                                if (empty($row)) {

                                                ?>
                                                    <button type='button' class='btn btn-primary btn-sm' style='margin-left: 10px;' data-toggle="modal" data-target="#getParent"><i class='bi bi-cloud-download-fill mx-2'></i>Send</button>
                                                <?php
                                                } else
                                                    echo "<div><i class='bi bi-check-circle text-success'> Done</i></div>";
                                                ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="col-sm-12 d-flex justify-md-end">
                                                    <p class="text-sm">Click the button below to download a file:<br><a href="download.php"><i class="bi bi-download mx-2"></i> Download File</a></p>
                                                </div>
                                                <div class="col-sm-2 d-flex justify-content-end">
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-8">
                                                    <p class="blockquote mb-0">PhilHealth ID</p>
                                                </div>
                                                <div class="col-sm-4 d-flex justify-content-end">
                                                    <?php
                                                    include 'db_connect.php';
                                                    if ($mysqli->connect_errno) {
                                                        die("Connection error: " . $mysqli->connect_error);
                                                    }
                                                    $user = $_SESSION["user"];
                                                    $sql = "SELECT * from philhealth_id_db where std_id=$user";
                                                    $result = $mysqli->query($sql);
                                                    $row = $result->fetch_assoc();
                                                    if (empty($row)) {

                                                    ?>
                                                        <button type='button' class='btn btn-primary btn-sm' data-toggle="modal" data-target="#getPhilId"><i class="bi bi-cloud-download-fill mx-2"></i>Send</button>
                                                    <?php
                                                    } else
                                                        echo "<div><i class='bi bi-check-circle text-success'> Done</i></div>";
                                                    ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class=" col-sm-8">
                                                    <p class="blockquote mb-0">Certification of Vaccination</p>
                                                </div>
                                                <div class="col-sm-4 d-flex justify-content-end">
                                                    <?php
                                                    include 'db_connect.php';
                                                    if ($mysqli->connect_errno) {
                                                        die("Connection error: " . $mysqli->connect_error);
                                                    }
                                                    $user = $_SESSION["user"];
                                                    $sql = "SELECT * from cer_vac_db where std_id=$user";
                                                    $result = $mysqli->query($sql);
                                                    $row = $result->fetch_assoc();
                                                    if (empty($row)) {

                                                    ?>
                                                        <button type='button' class='btn btn-primary btn-sm' style='margin-left: 10px; ' data-toggle="modal" data-target="#getCerVac"><i class='bi bi-cloud-download-fill mx-2'></i>Send</button>
                                                    <?php
                                                    } else
                                                        echo "<div><i class='bi bi-check-circle text-success'> Done</i></div>";
                                                    ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <?php
                                            include 'db_connect.php';
                                            if ($mysqli->connect_errno) {
                                                die("Connection error: " . $mysqli->connect_error);
                                            }
                                            $user = $_SESSION["user"];
                                            $sql = "SELECT * from student_infomation where id=$user";
                                            $result = $mysqli->query($sql);
                                            while ($row = $result->fetch_assoc()) {
                                                if ($row['sex'] == "Female") {
                                            ?>
                                                    <div class="row">
                                                        <div class="col-sm-8">
                                                            <p class="blockquote mb-0">Pregnancy Test <small><i>(for female only)</i></small></p>
                                                        </div>
                                                        <div class="col-sm-4 d-flex justify-content-end">
                                                            <?php
                                                            $sql2 = "SELECT * from pregnancy_db where std_id=$user";
                                                            $result2 = $mysqli->query($sql2);
                                                            $row = $result->fetch_assoc();
                                                            if (empty($row)) {

                                                            ?>
                                                                <button type='button' class='btn btn-primary btn-sm' style='margin-left: 10px;' data-toggle="modal" data-target="#getPregtest"><i class='bi bi-cloud-download-fill mx-2'></i>Send</button>
                                                            <?php
                                                            } else
                                                                echo "<div><i class='bi bi-check-circle text-success'> Done</i></div>";
                                                            ?>
                                                        </div>
                                                    </div>
                                            <?php

                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" id="getParent">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Parent Consent</h4>
                    <button type="button" class="btn-close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="upload_consent.php" method="post" enctype="multipart/form-data">
                        <div class="input-group mb-3 pb-2">
                            <div class="custom-file">
                                <p class="lead">Insert file that contains parental consent.</p>
                                <input type="file" class="form-control form-control-sm" name="document">
                            </div>
                        </div>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" type="submit" name="submit" value="Upload">
                </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal" id="getPhilId">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">PhilHealth ID</h4>
                    <button type="button" class="btn-close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="upload_phil.php" method="post" enctype="multipart/form-data">
                        <div class="input-group mb-3 pb-2">
                            <div class="custom-file">
                                <p class="lead">Insert or capture a picture of your PhilHealth ID. <br>(Front of the ID)</p>
                                <input type="file" class="form-control form-control-sm" name="image1" id="image1">
                            </div>
                        </div>
                        <input class="btn btn-secondary btn-sm " type="button" value="Take Picture" onclick="captureImage()">
                        <div class="input-group mb-3 pb-2">
                            <div class="custom-file">
                                <p class="lead">Insert or capture a picture of your PhilHealth ID. <br>(Back of the ID)</p>
                                <input type="file" class="form-control form-control-sm" name="image2" id="image2">
                            </div>
                        </div>
                        <input class="btn btn-secondary btn-sm " type="button" value="Take Picture" onclick="captureImage()">

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" type="submit" name="submit" value="Upload">
                </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal" id="getCerVac">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Certification of Vaccination</h4>
                    <button type="button" class="btn-close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="upload_cervac.php" method="post" enctype="multipart/form-data">
                        <div class="input-group mb-3 pb-2">
                            <div class="custom-file">
                                <p class="lead">Insert or capture a picture of your Certification of Vaccination. <br>(Front of the ID)</p>
                                <input type="file" class="form-control form-control-sm" name="image1" id="image1">
                            </div>
                        </div>
                        <input class="btn btn-secondary btn-sm " type="button" value="Take Picture" onclick="captureImage()">
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" type="submit" name="submit" value="Upload">
                </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal" id="getPregtest">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Pregnancy Test</h4>
                    <button type="button" class="btn-close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="upload_cervac.php" method="post" enctype="multipart/form-data">
                        <div class="input-group mb-3 pb-2">
                            <div class="custom-file">
                                <p class="lead">Insert or capture a picture of your Pregnancy Test.
                                    <input type="file" class="form-control form-control-sm" name="image1" id="image1">
                            </div>
                        </div>
                        <input class="btn btn-secondary btn-sm " type="button" value="Take Picture" onclick="captureImage()">
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" type="submit" name="submit" value="Upload">
                </div>
                </form>
            </div>
        </div>
    </div>
    <?php include 'script.php' ?>
    <script>
        // Function to capture image from camera
        function captureImage() {
            navigator.mediaDevices.getUserMedia({
                    video: true
                })
                .then(function(stream) {
                    var video = document.createElement('video');
                    video.srcObject = stream;
                    video.onloadedmetadata = function(e) {
                        video.play();
                    };
                    var canvas = document.createElement('canvas');
                    canvas.width = 640;
                    canvas.height = 480;
                    var context = canvas.getContext('2d');
                    setInterval(function() {
                        context.drawImage(video, 0, 0, canvas.width, canvas.height);
                        var data = canvas.toDataURL('image/png');
                        document.getElementById('image1').value = data;
                        document.getElementById('image2').value = data;
                    }, 100);
                })
                .catch(function(err) {
                    console.log("An error occurred: " + err);
                });
        }
    </script>
</body>

</html>