<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                <?php
                include 'db_connect.php';
                $user=$_SESSION["user"];
                $sql20 = "SELECT * from user_profile join student_infomation on user_profile.std_id=student_infomation.id Where user_profile.std_id=$user";
                if ($result20 = $mysqli->query($sql20))
                while ($row20 = $result20->fetch_assoc()) {
                ?>
                    <a class="nav-link" href="profile.php">
                        <div class="container-sm">
                            <img src="<?php echo $row20['profile'] ?>" class="card-rounded mx-auto d-block" style="width: 150px; height: 160px;" alt="...">
                            <div class="card-body text-center">
                            <h6 class="my-3"><?php echo $row20['firstname']." ".$row20['surname'] ?></h6>
                                <p class="card-text"><?php echo $row20['id'] ?></p>
                            </div>
                        </div>
                    </a>
                    <?php
                     }
                     ?>
                    <div class="sb-sidenav-menu-heading">MENU</div>
                    <a class="nav-link" href="index.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                    <a class="nav-link" href="requirements.php">
                        <div class="sb-nav-link-icon"><i class="bi bi-list-task"></i></div>
                        Requirements
                    </a>
                    <a class="nav-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseLayouts3" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-message"></i></div>
                        Message
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts3" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="message.php">
                                <div class="sb-nav-link-icon"><i class="bi bi-chat-dots"></i></i></div>
                                Message
                            </a>
                            <a class="nav-link" href="inbox.php">
                                <div class="sb-nav-link-icon"><i class="bi bi-chat-dots-fill"></i></div>
                                Inbox
                            </a>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Made By:</div>
                Team IT-ech
            </div>
        </nav>
    </div>
</body>

</html>