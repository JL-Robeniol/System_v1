<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title " id="ModalLabel">Delete Student information</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-center">Are you sure you want to Delete?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary  btn-sm" data-bs-dismiss="modal">Close</button>
                <a href="delete_admin.php?id=<?php echo $row['id']; ?>" class="btn btn-danger  btn-sm"> Yes</a>
            </div>
        </div>
    </div>
</div>


<!-- view -->
<div class="modal fade" id="view_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">Student Information</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card-header bg-black text-white">
                    <i class="text-white"></i>
                    Personal Information
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <p class="mb-0">Student ID</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row['id']; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Fullname</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["last_name"] . ", " . $row["first_name"] . " " . $row["middle_name"] . " " . $row["suffix_name"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Birthday</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo date("F d Y ", strtotime($row["birthday"])); ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Sex</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["sex"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Civil Status</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["civil_status"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Citezenship</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["citizenship"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Blood Type</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["blood_type"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Height</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["height"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Weight</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["weight"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Telephone No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["tel_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Mobile No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["mobile_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Email</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["email"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">GSIS No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["gsis_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Pagibig No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["pagibig_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">PhilHealth No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["philhealth_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">SSS No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["sss_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="col-sm-4">
                        <p class="mb-0">Employee No.</p>
                    </div>
                    <div class="col-sm-8">
                        <p class="text-muted mb-0"><?php echo $row["employee_no"]; ?></p>
                    </div>
                    <hr>
                    <div class="card-header bg-black text-white">
                        <i class="text-white"></i>
                        Family Background
                    </div>
                    <?php
                    include 'db_connect.php';
                    $student = $row['id'];
                    $sql2 = "SELECT * FROM student_family_bg where id=$student;";
                    $result2 = $mysqli->query($sql2);
                    if (!$result2) {
                        die("Invalid query: " . $mysqli->error);
                    }
                    while ($row2 = $result2->fetch_assoc()) {
                    ?>
                        <div class="col-sm-4">
                            <p class="mb-0">Father Fullname</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["father_surname"] . ", " . $row2["father_firstname"] . " " . $row2["father_middlename"] . " " . $row2["father_suffixname"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Occupation</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["father_occupation"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Mobile No.</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["father_mobile_no"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Mother Fullname</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["mother_surname"] . ", " . $row2["mother_firstname"] . " " . $row2["mother_middlename"] . " - " . $row2["mother_maidenname"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Occupation</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["mother_occupation"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Mobile No.</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["mother_mobile_no"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Spouse Fullname</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_surname"] . ", " . $row2["spouse_firstname"] . " " . $row2["spouse_middlename"] . " - " . $row2["spouse_suffixname"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Occupation</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_occupation"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Employer name</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_employer_name"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Business Address</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_business_address"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Telephone No.</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_tel_no"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Mobile No.</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row2["spouse_mobile_no"]; ?></p>
                        </div>
                        <hr>
                    <?php
                    }
                    ?>
                    <div class="card-header bg-black text-white">
                        <i class="text-white"></i>
                        Address Background
                    </div>
                    <?php
                    include 'db_connect.php';
                    $student = $row['id'];
                    $sql3 = "SELECT * FROM student_address_bg where id=$student;";
                    $result3 = $mysqli->query($sql3);
                    if (!$result3) {
                        die("Invalid query: " . $mysqli->error);
                    }
                    while ($row3 = $result3->fetch_assoc()) {
                    ?>
                        <div class="col-sm-4">
                            <p class="mb-0">Birth Place</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row3["bop_barangay"] . ", " . $row3["bop_municipal"] . ", " . $row3["bop_province"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Recidential Address</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row3["ra_house_no"] . ", " . $row3["ra_street"] . ", " . $row3["ra_village"] . ", " . $row3["ra_barangay"] . ", " . $row3["ra_municipal"] . ", " . $row3["ra_province"] . ", " . $row3["ra_zipcode"]; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Permanent Address</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row3["pa_house_no"] . ", " . $row3["pa_street"] . ", " . $row3["pa_village"] . ", " . $row3["pa_barangay"] . ", " . $row3["pa_municipal"] . ", " . $row3["pa_province"] . ", " . $row3["pa_zipcode"]; ?></p>
                        </div>
                        <hr>
                    <?php
                    }
                    ?>
                    <div class="card-header bg-black text-white">
                        <i class="text-white"></i>
                        Education Background
                    </div>
                    <?php
                    include 'db_connect.php';
                    $student = $row['id'];
                    $sql4 = "SELECT * FROM student_education_bg where id=$student;";
                    $result4 = $mysqli->query($sql4);
                    if (!$result4) {
                        die("Invalid query: " . $mysqli->error);
                    }
                    while ($row4 = $result4->fetch_assoc()) {
                    ?>
                        <div class="col-sm-4">
                            <p class="mb-0">Elementary School</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row4["elemtary_school"] . ", (" . $row4["elemtary_school_poa"]. ")" ; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Secondary School</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row4["secondary_school"] . ", (" . $row4["secondary_school_poa"]. ")" ; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">Course School</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row4["course_school"] . ", (" . $row4["course_school_poa"]. ")" ; ?></p>
                        </div>
                        <hr>
                        <div class="col-sm-4">
                            <p class="mb-0">College</p>
                        </div>
                        <div class="col-sm-8">
                            <p class="text-muted mb-0"><?php echo $row4["college"] . ", (" . $row4["college_poa"]. ")" ; ?></p>
                        </div>
                        <hr>

                    <?php
                    }
                    ?>
                </div>
                <hr>
            </div>
        </div>
    </div>
</div>