<?php

session_start();
include 'db_connect.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id = $_POST["studentid"];
    $lname = $_POST["lastname"];
    $fname = $_POST["firstname"];
    $mname = $_POST["middlename"];
    $sname = $_POST["suffixname"];
    $block = $_POST["block"];
    $year = $_POST["year"];
    $password = $_POST["password"];

    do {

        if (empty($id) || empty($lname) || empty($fname) || empty($mname) || empty($sname) || empty($block) || empty($year) || empty($password)) {

            $_SESSION['errormessage'] = "All the field are required";
            break;
        } else {
            $sql = "INSERT INTO student_enroll (id,last_name,first_name, middle_name, suffix_name, password, block, school_year)" .
                "VALUE ( '$id','$lname','$fname','$mname','$sname','$password','$block','$year')";

            $result = $mysqli->query($sql);

            if (!$result) {
                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                break;
            }
            $id = "";
            $lname = "";
            $fname = "";
            $mname = "";
            $sname = "";
            $block = "";
            $year = "";
            $password = "";
            $_SESSION['successmessage'] = "Successful";
            header("location: /CCJE_Monitoring_System/admin/student_enrolled.php");
            exit;
        }
    } while (false);
}
