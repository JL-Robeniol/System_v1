<?php
session_start();
include 'db_connect.php';

if (isset($_POST["submit"])) {
  if (!empty($_FILES['document']['name'])) {
    $file_name = basename($_FILES["document"]["name"]);
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $temp_file = $_FILES["document"]["tmp_name"];
    $file_destination = "../uploads/" . $file_name;
    $stdid = $_SESSION["user"];
    // Insert image content into database 
    $insert = $mysqli->query("INSERT into parent_con_db (std_id,file1) VALUES ('$stdid','$file_destination')");

    if (move_uploaded_file($_FILES['document']['tmp_name'], $file_destination)) {
      $_SESSION['successmessage'] = "File uploaded successfully.";
      header("location: /CCJE_Monitoring_System/student/requirements.php");
    } else {
      $_SESSION['errormessage'] = "Error uploading file.";
      header("location: /CCJE_Monitoring_System/student/requirements.php");
    }
    header("location: /CCJE_Monitoring_System/student/requirements.php");
    
  }
}
