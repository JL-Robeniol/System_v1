<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title " id="ModalLabel">Delete Student Enrolled</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-center">Are you sure you want to Delete?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary  btn-sm" data-bs-dismiss="modal">Close</button>
                <a href="delete_student_enrolled.php?id=<?php echo $row['id']; ?>" class="btn btn-danger  btn-sm"> Yes</a>
            </div>
        </div>
    </div>
</div>


<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">Edit Student Enrolled</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="edit_student_enrolled.php?id=<?php echo $row['id']; ?>">
                    <div class="row clearfix">
                        <div class="col-md-12 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="text" name="studentid" class="form-control" placeholder="STUDENT ID" value="<?php echo $row['id']; ?>">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="text" name="lastname" class="form-control" placeholder="LAST NAME" value="<?php echo $row['last_name']; ?>">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="text" name="firstname" class="form-control" placeholder="FIRST NAME" value="<?php echo $row['first_name']; ?>">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="text" name="middlename" class="form-control" placeholder="MIDDLE NAME" value="<?php echo $row['middle_name']; ?>">
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 mb-2">
                            <div class="form-group">
                                <select name="suffixname" class="form-control custom-select">
                                    <option value="<?php echo $row['suffix_name']; ?>"><?php echo $row['suffix_name']; ?></option>
                                    <option value=" ">N/A</option>
                                    <option value="Jr">Jr</option>
                                    <option value="Sr">Sr</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                    <option value="V">V</option>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="col-md-4 col-sm-12 mb-2">
                            <div class="form-group">
                                <select name="block" class="form-control custom-select">
                                    <option value="<?php echo $row['block']; ?>"><?php echo $row['block']; ?></option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="text" name="year" class="form-control" placeholder="SCHOOL YEAR" value="<?php echo $row['school_year']; ?>">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-2">
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="PASSWORD" value="<?php echo $row['password']; ?>">
                            </div>
                        </div>
                        <br>
                        <div class="col-sm-12 mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="student_enrolled.php" class="btn btn-outline-secondary" title="">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>