<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Attendance Report</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-4">Attendance Report</h1>
                                </h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Tables</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <?php

                    if (isset($_SESSION['successmessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Successful</strong>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['successmessage']);
                    }
                    ?>
                    <?php

                    if (isset($_SESSION['errormessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Error:</strong> <?php echo $_SESSION['errormessage']; ?>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['errormessage']);
                    }
                    ?>
                    <div class="card">
                        <div class="card-header">
                            Attendance Report
                        </div>
                        <div class="card-body">
                            <form method="get" action="report.php">
                                <div class="row clearfix">
                                    <div class="col-md-3 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">Station</label>
                                            <select name="stationid" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                                <?php
                                                include 'db_connect.php';
                                                $sql = "SELECT * FROM `station_info`";
                                                $result = $mysqli->query($sql);
                                                if (!$result) {
                                                    die("Invalid query: " . $mysqli->error);
                                                }
                                                while ($row = $result->fetch_assoc()) {
                                                ?>
                                                    <option value='<?php echo $row['sti_id']; ?>'><?php echo $row['sti_id'] . " - " . $row['sti_station'] . " - " . $row['sti_barangay'] . ", " . $row['sti_municipal'] . ", " . $row['sti_region']; ?></option>
                                                <?php

                                                }
                                                mysqli_close($mysqli);
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">Status</label>
                                            <select name="status" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                                <option value="present">Present</option>
                                                <option value="late">Late</option>
                                                <option value="absent">Absent</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">Date</label>
                                            <input type="date" name="date" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="col-sm-12 mb-3">
                                        <button type="submit" name="submit" class="btn btn-primary btn-sm">Go</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <?php
                        include 'db_connect.php';
                        if (!empty($_GET["stationid"]) ||  !empty($_GET["status"]) || !empty($_GET['date'])) {
                            $station = $_GET["stationid"];
                            $status = $_GET["status"];
                            $date = $_GET['date'];
                            $sql2 = "SELECT * FROM attendance JOIN student_infomation ON student_infomation.id=attendance.std_id JOIN station_info on station_info.sti_id=attendance.sti_id WHERE attendance.sti_id='$station' AND attendance.att_attend='$status' AND attendance.att_date BETWEEN '$date' AND '$date';";
                            $result2 = $mysqli->query($sql2);
                            if (!$result2) {
                                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                                header("location: /CCJE_Monitoring_System/admin/report.php");
                            }
                        ?>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="cell">ID</th>
                                            <th class="cell">Name</th>
                                            <th class="cell">Station - Area</th>
                                            <th class="cell">Status</th>
                                            <th class="cell">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    if (mysqli_num_rows($result2) > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            echo   "
                                                                            <tr>
                                                                            <td>$row2[std_id]</td>
                                                                            <td>$row2[surname], $row2[firstname] $row2[middlename]  $row2[suffixname]</td>
                                                                            <td>$row2[sti_id] - $row2[sti_station], $row2[sti_barangay], $row2[sti_municipal], $row2[sti_region]</td>
                                                                            <td>$row2[att_attend]</td>
                                                                            <td>$row2[att_date]</td>
                                                                            </tr>
                                                ";
                                        }
                                        $_SESSION['successmessage'] = "Successful";
                                    } else {
                                        echo "No results found.";
                                    }
                                }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>