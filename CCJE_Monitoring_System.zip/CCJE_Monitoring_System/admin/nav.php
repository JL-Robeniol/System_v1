<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">MENU</div>
                    <a class="nav-link" href="index.php">
                        <div class="sb-nav-link-icon btn-sm"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                    <a class="nav-link collapsed btn-sm" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts1" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon btn-sm"><i class="bi bi-people-fill"></i></div>
                        User Information
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="student_table.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="fas fa-user"></i></div>
                                Student List
                            </a>
                            <a class="nav-link" href="team_leader_table.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="fas fa-user"></i></div>
                                Team Leader
                            </a>
                            <a class="nav-link" href="admin.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="fas fa-user"></i></div>
                                Admin
                            </a>
                        </nav>
                    </div>
                    <a class="nav-link collapsed btn-sm" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts4" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon btn-sm"><i class="bi bi-archive"></i></div>
                        Reports
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts4" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="report.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-card-checklist"></i></i></div>
                               Attendance Report
                            </a>
                            <a class="nav-link" href="sub_report.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-card-list"></i></div>
                                Submission Report
                            </a>
                        </nav>
                    </div>

                    <a class="nav-link" href="student_enrolled.php">
                        <div class="sb-nav-link-icon btn-sm"><i class="bi bi-list-ul"></i></div>
                        Student Enrolled
                    </a>
                    <a class="nav-link collapsed btn-sm" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts2" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon btn-sm"><i class="bi bi-building"></i></div>
                        Station Information
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts2" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="station_info.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-building-dash"></i></div>
                                Station Info
                            </a>
                            <a class="nav-link" href="student_station_assign.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-building-add"></i></div>
                                Student Station Assign
                            </a>
                        </nav>
                    </div>
                    <a class="nav-link" href="att_report.php">
                        <div class="sb-nav-link-icon btn-sm"><i class="fas fa-book"></i></div>
                        Attendance
                    </a>
                    <a class="nav-link" href="sub_requirement.php">
                        <div class="sb-nav-link-icon btn-sm"><i class="fas fa-book"></i></div>
                        Submitted Requirements
                    </a>
                    <a class="nav-link" href="post.php">
                        <div class="sb-nav-link-icon btn-sm"><i class="fas fa-pen-to-square"></i></div>
                        Announcement News
                    </a>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts3" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon btn-sm"><i class="fas fa-message"></i></div>
                        Message
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts3" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="message.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-chat-dots"></i></div>
                                Message
                            </a>
                            <a class="nav-link" href="inbox.php">
                                <div class="sb-nav-link-icon btn-sm"><i class="bi bi-chat-dots-fill"></i></div>
                                Inbox
                            </a>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Made By:</div>
                Team IT-ech
            </div>
        </nav>
    </div>
</body>

</html>