<?php
session_start();

$host = "localhost";
$dbname = "ccje_db";
$username = "root";
$password = "";

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli->connect_error);
}

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userid = $_POST["userID"];
    $pass = $_POST["userpass"];
    $identity = $_POST["identity"];

    if ($identity == 'Student') {

        $sql = "SELECT * from student_enroll Where id=$userid";
        if ($result = $mysqli->query($sql)) {
            while ($row = $result->fetch_assoc()) {
                if ($pass == $row['password']) {
                    $_SESSION["user"] = $row['id'];
                    header("location: /CCJE_Monitoring_System/check_student.php");
                } else {
                    $errorMessage = "Wrong Password and Username";
                }
            }
        }
    }


    if ($identity == "Team Leader") {

        $sql = "SELECT * from team_leader_student where tl_id=$userid";
        if ($result = $mysqli->query($sql)) {
            while ($row = $result->fetch_assoc()) {
                $sql2 = "SELECT * from student_enroll where id=$userid";
                if ($result2 = $mysqli->query($sql2)) {
                    while ($row2 = $result2->fetch_assoc()) {
                        if ($row2['password'] == $pass) {
                            $_SESSION["user"] = $row2['id'];
                             $_SESSION["userstation"]= $row['sti_id'];
                            $_SESSION["username"] = $row2['last_name'];
                            header("location: /CCJE_Monitoring_System/team_leader/index.php");
                        }
                    }
                }
            }
        }
    } else {
        $errorMessage = "identity are invalide";
    }

    if ($identity == "Admin") {
        $sql = "SELECT * from admin_db Where admin_id=$userid";
        if ($result = $mysqli->query($sql)) {
            while ($row = $result->fetch_assoc()) {
                if (password_verify($pass, $row['admin_password'])) {
                    $_SESSION["user"] = $row['admin_id'];
                    $_SESSION["username"] = $row['admin_lname'];
                    header("location: /CCJE_Monitoring_System/admin/index.php");
                } else {
                    $errorMessage = "Wrong Password and Username";
                }
            }
        }
    } else {
        $errorMessage = "identity are invalide";
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-danger">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <<div class="px-5 py-5 px-md-5 text-center text-lg-start rounded" style="background-color: hsl(44, 100%, 55%)">
                            <div class="container rounded">
                                <div class="row gx-lg-5 align-items-center">
                                    <div class="col-lg-6 mb-5 mb-lg-0">
                                        <h1 class="my-2 display-3 fw-bold ls-tight">
                                            COLLEGE OF CRIMINAL <br />
                                            <span class="text-danger">JUSTICE EDUCATION</span>
                                        </h1>
                                        <p style="color: hsl(44, 100%, 0%)">
                                            Honing high-caliber criminologists and principled law enforcers, while inculcating the spirit of nationalism, accountability, and justice.
                                        </p>
                                    </div>
                                    <div class="col-lg-6 mb-5 mb-lg-0">
                                        <div class="card rounded">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-center">
                                                    <img class="img-fluid rounded mb-2" src="logoccje.jpg" width="105" height="105">
                                                </div>
                                                <h5 class="d-flex justify-content-center">URDANETA CITY UNIVERSITY</h5>
                                                <p class="h6 fw-light d-flex justify-content-center">COLLEGE OF CRIMINAL JUSTICE EDUCATION</p>
                                            </div>
                                            <div class="card-body py-1 px-md-5 rounded">
                                                <form action="index.php" method="post">
                                                    <?php
                                                    if (!empty($errorMessage)) {
                                                        echo "
                                                    <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                                                    <strong>$errorMessage</strong>
                                                    <button type'button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>
                                                    </div>
                                                    ";
                                                    }
                                                    ?>
                                                    <br>
                                                    <div class="form-floating mb-2">
                                                        <select class="custom-control-center mb-3" name="identity">
                                                            <option value="Student">Student</option>
                                                            <option value="Team Leader">Team Leader</option>
                                                            <option value="Admin">Admin</option>
                                                        </select>
                                                        <div class="form-floating mb-3">
                                                            <input class="form-control" id="inputEmail" type="text" name="userID" placeholder="Student ID" />
                                                            <label for="inputID">ID</label>
                                                        </div>
                                                        <div class="form-floating mb-4">
                                                            <input class="form-control" id="inputPassword" type="password" name="userpass" placeholder="Password" />
                                                            <label for="inputPassword">Password</label>

                                                        </div>
                                                        <div class="d-flex justify-content-md-center mb-4">
                                                            <button type="submit" class="btn btn-primary btn-lg btn-block">Log In</button>
                                                        </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
        </div>
    </div>
    </main>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js"></script>
    <script src="../assets/js/core.js"></script>
    <script src="../assets/js/form/dropify.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="../js/datatables-simple-demo.js"></script>
</body>

</html>