<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Submission Report</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-4">Submission Report</h1>
                                </h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Tables</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <?php

                    if (isset($_SESSION['successmessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Successful</strong>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['successmessage']);
                    }
                    ?>
                    <?php

                    if (isset($_SESSION['errormessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Error:</strong> <?php echo $_SESSION['errormessage']; ?>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['errormessage']);
                    }
                    ?>
                    <div class="card">
                        <div class="card-header">
                            Submission Report
                        </div>
                        <div class="card-body">
                            <form method="get" action="sub_report.php">
                                <div class="row clearfix">
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">ID - Student Name</label>
                                            <select name="student" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                                <?php
                                                include 'db_connect.php';
                                                $sql3 = "SELECT * from student_infomation ";
                                                $result3 = $mysqli->query($sql3);
                                                if (!$result3) {
                                                    die("Invalid query: " . $mysqli->error);
                                                }
                                                while ($row3 = $result3->fetch_assoc()) {
                                                ?>

                                                    <option value='<?php echo $row3['id']; ?>'><?php echo $row3['id'] . " - " . $row3['surname'] . ", " . $row3['firstname'] . " " . $row3['middlename'] . " " . $row3['suffixname']; ?></option>

                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">Submitted</label>
                                            <select name="file" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                                <option value="parent_con_db">Parent Consent</option>
                                                <option value="philhealth_id_db">PhilHealth ID</option>
                                                <option value="cer_vac_db">Certification of Vaccination</option>
                                                <option value="pregnancy_db">Pregnancy Test</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="col-sm-12 mb-3">
                                        <button type="submit" class="btn btn-primary btn-sm">Go</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php
                        include 'db_connect.php';
                        if (!empty($_GET["student"]) ||  !empty($_GET["file"])) {
                            $student = $_GET["student"];
                            $file = $_GET["file"];
                            $sql2 = "SELECT * FROM $file JOIN student_infomation ON student_infomation.id=$file.std_id  WHERE $file.std_id='$student' ;";
                            $result2 = $mysqli->query($sql2);
                            if (!$result2) {
                                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                            }
                        ?>
                            <?php
                            if ($file == "cer_vac_db" or $file == "pregnancy_db") {
                            ?>
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="cell">ID</th>
                                                <th class="cell">Name</th>
                                                <th class="cell">File/Image</th>
                                                <th class="cell">Download</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if (mysqli_num_rows($result2) > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                echo   "
                                                                            <tr>
                                                                            <td>$row2[std_id]</td>
                                                                            <td>$row2[surname], $row2[firstname] $row2[middlename]  $row2[suffixname]</td>
                                                                            <td><img src='$row2[image1]' class='img post_img' style='width:150px; height:150px;' /></td>
                                                                           
                                                                            </tr>
                                                ";
                                            }
                                            $_SESSION['successmessage'] = "Successful";
                                        } else {
                                            echo "No results found.";
                                        }
                                    }
                                        ?>
                                        <?php

                                        if ($file == "philhealth_id_db") {
                                        ?>
                                            <div class="card-body">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th class="cell">ID</th>
                                                            <th class="cell">Name</th>
                                                            <th class="cell">File/Image 1</th>
                                                            <th class="cell">File/Image 2</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        if (mysqli_num_rows($result2) > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                echo   "
                                                                        <tr>
                                                                        <td>$row2[std_id]</td>
                                                                        <td>$row2[surname], $row2[firstname] $row2[middlename]  $row2[suffixname]</td>
                                                                        <td><img src='$row2[image1]' class='img post_img' style='width:150px; height:150px;' /></td>
                                                                        <td><img src='$row2[image2]' class='img post_img' style='width:150px; height:150px;' /></td>
                                                                        
                                                                        </tr>
                                            ";
                                                            }
                                                            $_SESSION['successmessage'] = "Successful";
                                                        } else {
                                                            echo "No results found.";
                                                        }
                                                        ?>
                                                    <?php
                                                } 
                                                if($file == "parent_con_db") {
                                                    ?>
                                                        <div class="card-body">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="cell">ID</th>
                                                                        <th class="cell">Name</th>
                                                                        <th class="cell">File/Image 1</th>
                                                                        <th class="cell">Download</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php
                                                                    if (mysqli_num_rows($result2) > 0) {
                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                            echo   "
                                                                        <tr>
                                                                        <td>$row2[std_id]</td>
                                                                        <td>$row2[surname], $row2[firstname] $row2[middlename]  $row2[suffixname]</td>
                                                                        <td>". ltrim($row2["file1"],'\.\./uploads/')."</td>
                                                                        <td><a href='download.php?file=$row2[file1]'>". ltrim($row2["file1"],'\.\./uploads/')."<i class='bi bi-download'></i></a></td>
                                                                        </tr>
                                            ";
                                                                        }
                                                                        $_SESSION['successmessage'] = "Successful";
                                                                    } else {
                                                                        echo "No results found.";
                                                                    }
                                                                    ?>
                                                            <?php
                                                        }
                                                    }
                                                            ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                            </div>
            </main>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>