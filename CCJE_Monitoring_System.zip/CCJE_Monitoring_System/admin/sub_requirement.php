<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Requirements</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-4">Submitted Requirements</h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Tables</li>
                                </ol>
                                <?php

                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <div class="card-body">
                        <button type="button" class="btn btn-white border border-dark" data-bs-toggle="modal" data-bs-target="#getParent"><i class="bi bi-folder"></i> Parent Consent</button>
                        <button type="button" class="btn btn-white border border-dark" data-bs-toggle="modal" data-bs-target="#getPhil"><i class="bi bi-folder"></i> PhilHealth ID</button>
                        <button type="button" class="btn btn-white border border-dark" data-bs-toggle="modal" data-bs-target="#getCer"><i class="bi bi-folder"></i> Certification of Vaccination</button>
                        <button type="button" class="btn btn-white border border-dark" data-bs-toggle="modal" data-bs-target="#getPreg"><i class="bi bi-folder"></i> Pregnancy Test</button>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <div class="modal fade" id="getParent" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Parent Consent</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table id="datatablesSimple" class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="cell">Student ID</th>
                                <th class="cell">Student Name</th>
                                <th class="cell">File</th>
                                <th class="cell">Submitted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'db_connect.php';
                            $sql = "SELECT * FROM parent_con_db JOIN student_infomation on parent_con_db.std_id=student_infomation.id;";
                            $result = $mysqli->query($sql);
                            if (!$result) {
                                die("Invalid query: " . $mysqli->error);
                            }
                            while ($row = $result->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></td>
                                    <td><?php echo $row['file1']; ?></td>
                                    <td><?php echo $row['date']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="getPhil" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">PhilHealth ID</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table id="datatablesSimple2" class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="cell">Student ID</th>
                                <th class="cell">Student Name</th>
                                <th class="cell">Image(front)</th>
                                <th class="cell">Image(back)</th>
                                <th class="cell">Submitted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'db_connect.php';
                            $sql = "SELECT * FROM philhealth_id_db JOIN student_infomation on philhealth_id_db.std_id=student_infomation.id;";
                            $result = $mysqli->query($sql);
                            if (!$result) {
                                die("Invalid query: " . $mysqli->error);
                            }
                            while ($row = $result->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></td>
                                    <td><img src='<?php echo $row['image1']; ?>' class='img post_img' style='width:150px; height:150px;' /></td>
                                    <td><img src='<?php echo $row['image2']; ?>' class='img post_img' style='width:150px; height:150px;' /></td>
                                    <td><?php echo $row['date']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="getCer" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Certification of Vaccination</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table id="datatablesSimple" class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="cell">Student ID</th>
                                <th class="cell">Student Name</th>
                                <th class="cell">Image</th>
                                <th class="cell">Submitted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'db_connect.php';
                            $sql = "SELECT * FROM cer_vac_db JOIN student_infomation on cer_vac_db.std_id=student_infomation.id;";
                            $result = $mysqli->query($sql);
                            if (!$result) {
                                die("Invalid query: " . $mysqli->error);
                            }
                            while ($row = $result->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></td>
                                    <td><img src='<?php echo $row['image1']; ?>' class='img post_img' style='width:150px; height:150px;' /></td>
                                    <td><?php echo $row['date']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="getPreg" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Pregnancy Test</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table id="datatablesSimple" class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="cell">Student ID</th>
                                <th class="cell">Student Name</th>
                                <th class="cell">Image</th>
                                <th class="cell">Submitted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'db_connect.php';
                            $sql = "SELECT * FROM pregnancy_db JOIN student_infomation on pregnancy_db  .std_id=student_infomation.id;";
                            $result = $mysqli->query($sql);
                            if (!$result) {
                                die("Invalid query: " . $mysqli->error);
                            }
                            while ($row = $result->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></td>
                                    <td><img src='<?php echo $row['image1']; ?>' class='img post_img' style='width:150px; height:150px;' /></td>
                                    <td><?php echo $row['date']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>