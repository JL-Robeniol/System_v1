<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Form</title>
</head>

<body class="bg-danger">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main class="bg" style="background-image: url('../upload/background.jpg');">
                <div class="container" style="padding: 25px 50px 75px;">>
                    <div class="row justify-content-center">
                        <div class="card sb-nav-fixed" style="padding: 25px 50px 75px;">
                            <div class="card-header">
                                <h1 class="text-center mt-4">PERSONAL DATA SHEET</h1>
                                <div class="row clearfix"><i><b class="text-danger">WARNING:</b> Any misrepresentation made in the Pesonal Data Sheet shall cause the filing of administrative/criminal case's against the person concerned.</i></div>
                                <div class="row clearfix"><i><b class="text-success">NOTE:</b> If the required information is NOT required, enter N/A</i></div>
                            </div>
                            <div class="card-header bg-black text-white">
                                <i class="text-white"></i>
                                Personal Information
                            </div>
                            <form action="add_student_information.php" method="post" class="card-body" required>
                                <div class="row clearfix">
                                    <input type="hidden" class="form-control" placeholder="ID number" value="<?php echo $_SESSION["user"] ?>" name="student_id">
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SURNAME" required name="student_surname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="FIRST NAME" required name="student_firstname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MIDDLE NAME" required name="student_middlename">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group" >
                                            <select class="form-control" required name="student_extensionname">
                                                <option disabled selected>EXTENSION&#40;jr,sr&#41;</option>
                                                <option value=" ">N/A</option>
                                                <option value="Jr">Jr</option>
                                                <option value="Sr">Sr</option>
                                                <option value="III">III</option>
                                                <option value="IV">IV</option>
                                                <option value="V">V</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input placeholder="BIRTHDAY" class="form-control" type="text" onfocus="(this.type='date')" onblur="(this.type='text')" id="date" required name="student_birthday"/>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group" >
                                            <select class="form-control" required name="student_sex">
                                                <option value="" selected disabled>SEX</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <select class="form-control" required name="student_civil_status">
                                                <option value="" selected disabled>CIVIL STATUS</option>
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                                <option value="Widowed">Widowed</option>
                                                <option value="Separated">Separated</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="CITIZENSHIP" required name="student_citizenship">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group" >
                                            <select class="form-control" required name="student_blood_type">
                                                <option value="" selected disabled>BLOOD TYPE</option>
                                                <option value="A+">A+</option>
                                                <option value="A-">A-</option>
                                                <option value="B+">B+</option>
                                                <option value="B-">B-</option>
                                                <option value="O+">O+</option>
                                                <option value="O-">O-</option>
                                                <option value="AB+">AB+</option>
                                                <option value="AB-">AB-</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="HEIGHT(m)" required name="student_height">
                                        </div>
                                    </div>
                                    <div class="col-md-1 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="WEIGHT(kg)" required name="student_weight">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="TELEPHONE NO." required name="student_tel_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOBILE NO." required name="student_mobile_no">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="EMAIL ADDRESS" required name="student_email">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="GSIS ID NO." required name="student_gsis_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PAG-IBIG ID NO." required name="student_pagibig_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PHILHEALTH NO." required name="student_philhealth_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SSS NO." required name="student_sss_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="AGENCY EMPLOYEE NO." required name="student_employee_no">
                                        </div>
                                    </div>
                                    <div class="card-header bg-secondary text-white mb-2">
                                        <i class="text"></i>
                                        BIRTH OF PLACE
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PROVINCE" required name="student_bop_province">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="CITY/MUNICIPALITY" required name="student_bop_municipal">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="BARANGAY" required name="student_bop_barangay">
                                        </div>
                                    </div>
                                    <div class="card-header bg-secondary text-white mb-2">
                                        <i class="text"></i>
                                        RECIDENTIAL ADDRESS
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PROVINCE" required name="student_ra_province">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="CITY/MUNICIPALITY" required name="student_ra_municipal">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="BARANGAY" required name="student_ra_barangay">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SUBDIVISION/VILLAGE" required name="student_ra_village">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="STREET" required name="student_ra_street">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="HOUSE/BLOCK/LOT NO." required name="student_ra_house_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="ZIP CODE" required name="student_ra_zipcode">
                                        </div>
                                    </div>
                                    <div class="card-header bg-secondary text-white mb-2">
                                        <i class="text"></i>
                                        PERNAMENT ADDRESS
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PROVINCE" required name="student_pa_province">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="CITY/MUNICIPALITY" required name="student_pa_municipal">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="BARANGAY" required name="student_pa_barangay">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SUBDIVISION/VILLAGE" required name="student_pa_village">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="STREET" required name="student_pa_street">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="HOUSE/BLOCK/LOT NO." required name="student_pa_house_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="ZIP CODE" required name="student_pa_zipcode">
                                        </div>
                                    </div>

                                    <div class="card-header bg-black text-white mb-2">
                                        <i class="text-white"></i>
                                        FAMILY BACKGROUND
                                    </div>
                                    <div class="card-header bg-secondary text-white mb-2">
                                        <i class="text"></i>
                                        SPOUSE INFORMATION (If you have, N/A if NONE)
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SURNAME" required name="fb_si_surname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="FIRST NAME" required name="fb_si_firstname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MIDDLE NAME" required name="fb_si_middlename">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <select class="form-control" required name="fb_si_rxtensionname">
                                                <option disabled selected>EXTENSION&#40;jr,sr&#41;</option>
                                                <option value=" ">N/A</option>
                                                <option value=" ">N/A</option>
                                                <option value="Jr">Jr</option>
                                                <option value="Sr">Sr</option>
                                                <option value="III">III</option>
                                                <option value="IV">IV</option>
                                                <option value="V">V</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="OCCUPATION" required name="fb_si_occupation">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="EMPLOYER/BUSINESS NAME" required name="fb_si_employer_name">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="BUSINESS ADDRESS" required name="fb_si_business_add">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="TELEPHONE NO." required name="fb_si_tel_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOBILE NO." required name="fb_si_mobile_no">
                                        </div>
                                    </div>
                                    <div class="card-header bg-secondary text-white mb-2">
                                        <i class="text"></i>
                                        PARENTS INFORMATION
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="FATHER SURNAME" required name="fb_pi_f_surname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="FATHER FIRST NAME" required name="fb_pi_f_firstname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="FATHER MIDDLE NAME" required name="fb_pi_f_middlename">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <select class="form-control" required name="fb_pi_f_extensionname">
                                                <option disabled selected>EXTENSION&#40;jr,sr&#41;</option>
                                                <option value=" ">N/A</option>
                                                <option value="Jr">Jr</option>
                                                <option value="Sr">Sr</option>
                                                <option value="III">III</option>
                                                <option value="IV">IV</option>
                                                <option value="V">V</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="OCCUPATION" required name="fb_pi_f_occupation">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOBILE NO." required name="fb_pi_f_mobile_no">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  mb-2">
                                        <div class="form-group">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOTHER SURNAME" required name="fb_pi_m_surname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOTHER FIRST NAME" required name="fb_pi_m_firstname">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOTHER MIDDLE NAME" required name="fb_pi_m_middlename">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">

                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOTHER MAIDEN NAME" required name="fb_pi_m_maidenname">
                                        </div>

                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="OCCUPATION" required name="fb_pi_m_occupation">
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="MOBILE NO." required name="fb_pi_m_mobile_no">
                                        </div>
                                    </div>
                                    <div class="card-header bg-black text-white mb-2">
                                        <i class="text-white"></i>
                                        EDUCATIONAL BACKGROUND
                                    </div>
                                    <div class="col-md-5 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="ELEMENTARY SCHOOL NAME" required name="eb_elem_school">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PERIOD OF ATTENDANCE(ex.2018-2020)" required name="eb_elem_school_poa">
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="SECONDARY SCHOOL NAME" required name="eb_sec_school">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PERIOD OF ATTENDANCE(ex.2018-2020)" required name="eb_sec_school_poa">
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="EDUCATIONAL/GRADE COURCE SCHOOL NAME" required name="eb_cource_school">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PERIOD OF ATTENDANCE(ex.2018-2020)" required name="eb_cource_school_poa">
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="COLLEGE NAME" required name="eb_college">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 mb-2">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PERIOD OF ATTENDANCE(ex.2018-2020)" required name="eb_college_poa">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mb-2">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <a href="../index.php" class="btn btn-outline-secondary" title="">Cancel</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <?php include 'footer.php' ?>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>